# Project 2: linear algebra

Group members:

Hai Nguyen - hai_nguyen@csu.fullerton.edu
