# project-3-starter
Project 3: raytracer

Group members:

Hai Nguyen hai_nguyen@csu.fullerton.edu
